using Course.Controller;
using Course.Model;
using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Course.View;


namespace Course
{
    public partial class FormMain : Form
    {
        private BookManager bookManager;
        private BookController bookController;
        private CollectionController collectionController;
        private LibraryStorageController libraryStorage;

        public FormMain()
        {
            InitializeComponent();
            InitializeListViewColumns();

            this.FormClosing += FormMain_FormClosing;

            InitializeControllers();
            InitializeUI();
            LoadInitialBooks();
        }


        private void buttonAddBook_Click(object sender, EventArgs e)
        {
            bookController.AddBook(comboBoxCollections, comboBoxSort);
        }

        private void buttonDeleteBook_Click(object sender, EventArgs e)
        {
            bookController.DeleteBooks(comboBoxCollections, comboBoxSort);
        }


        private void buttonEditBook_Click_1(object sender, EventArgs e)
        {
            bookController.EditBook(comboBoxCollections, comboBoxSort);
        }

        private void listViewBooks_SelectedIndexChanged(object sender, EventArgs e)
        {}

        private void comboBoxSort_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
            {
                bookController.Sort(selectedCollection, (string)comboBoxSort.SelectedItem);
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            string query = textBoxSearch.Text.Trim();

            if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
            {
                bookController.Search(query, selectedCollection);
            }
            else
            {
                bookController.Search(query);
            }
        }


        private void buttonResetSearch_Click(object sender, EventArgs e)
        {
            textBoxSearch.Text = "";

            if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
            {
                bookController.ResetSearch(selectedCollection, (string)comboBoxSort.SelectedItem);
            }
        }

        private void comboBoxCollections_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
            {
                collectionController.CollectionChanging(selectedCollection, (string)comboBoxSort.SelectedItem);
            }
        }

        private void buttonCreateCollection_Click_1(object sender, EventArgs e)
        {
            collectionController.CreateCollection();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            libraryStorage.SaveToFile();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {}

        private void buttonDeleteCollection_Click_1(object sender, EventArgs e)
        {
            collectionController.DeleteCollection();
        }


        private void buttonEditCollection_Click(object sender, EventArgs e)
        {
            collectionController.EditCollection();
        }

    }
}