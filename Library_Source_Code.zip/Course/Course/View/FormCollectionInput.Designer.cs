﻿namespace Course.View
{
    partial class FormCollectionInput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCollectionInput));
            textBoxInput = new TextBox();
            buttonOK = new Button();
            buttonCancel = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // textBoxInput
            // 
            textBoxInput.Location = new Point(31, 145);
            textBoxInput.Name = "textBoxInput";
            textBoxInput.Size = new Size(430, 23);
            textBoxInput.TabIndex = 0;
            textBoxInput.TextChanged += textBoxInput_TextChanged;
            // 
            // buttonOK
            // 
            buttonOK.Location = new Point(335, 36);
            buttonOK.Name = "buttonOK";
            buttonOK.Size = new Size(126, 27);
            buttonOK.TabIndex = 1;
            buttonOK.Text = "ОК";
            buttonOK.UseVisualStyleBackColor = true;
            buttonOK.Click += buttonOK_Click;
            // 
            // buttonCancel
            // 
            buttonCancel.Location = new Point(335, 81);
            buttonCancel.Name = "buttonCancel";
            buttonCancel.Size = new Size(126, 27);
            buttonCancel.TabIndex = 2;
            buttonCancel.Text = "Відміна";
            buttonCancel.UseVisualStyleBackColor = true;
            buttonCancel.Click += buttonCancel_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 42);
            label1.Name = "label1";
            label1.Size = new Size(127, 15);
            label1.TabIndex = 3;
            label1.Text = "Введіть назву колекції";
            // 
            // FormCollectionInput
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(489, 208);
            Controls.Add(label1);
            Controls.Add(buttonCancel);
            Controls.Add(buttonOK);
            Controls.Add(textBoxInput);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximumSize = new Size(505, 247);
            MinimumSize = new Size(505, 247);
            Name = "FormCollectionInput";
            Text = "Нова колекція";
            Load += FormCollectionInput_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxInput;
        private Button buttonOK;
        private Button buttonCancel;
        private Label label1;
    }
}