﻿using Course.Controller;
using Course.Model;

namespace Course
{
    partial class FormMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            buttonAddBook = new Button();
            buttonEditBook = new Button();
            buttonDeleteBook = new Button();
            textBoxSearch = new TextBox();
            buttonSearch = new Button();
            listViewBooks = new ListView();
            buttonCreateCollection = new Button();
            comboBoxSort = new ComboBox();
            labelSort = new Label();
            buttonResetSearch = new Button();
            label1 = new Label();
            label2 = new Label();
            comboBoxCollections = new ComboBox();
            buttonDeleteCollection = new Button();
            buttonEditCollection = new Button();
            SuspendLayout();
            // 
            // buttonAddBook
            // 
            buttonAddBook.Location = new Point(408, 639);
            buttonAddBook.Name = "buttonAddBook";
            buttonAddBook.Size = new Size(162, 42);
            buttonAddBook.TabIndex = 1;
            buttonAddBook.Text = "Додати книгу";
            buttonAddBook.UseVisualStyleBackColor = true;
            buttonAddBook.Click += buttonAddBook_Click;
            // 
            // buttonEditBook
            // 
            buttonEditBook.Location = new Point(611, 639);
            buttonEditBook.Name = "buttonEditBook";
            buttonEditBook.Size = new Size(162, 42);
            buttonEditBook.TabIndex = 2;
            buttonEditBook.Text = "Редагувати дані про книгу";
            buttonEditBook.UseVisualStyleBackColor = true;
            buttonEditBook.Click += buttonEditBook_Click_1;
            // 
            // buttonDeleteBook
            // 
            buttonDeleteBook.Location = new Point(813, 639);
            buttonDeleteBook.Name = "buttonDeleteBook";
            buttonDeleteBook.Size = new Size(162, 42);
            buttonDeleteBook.TabIndex = 3;
            buttonDeleteBook.Text = "Видалити книгу";
            buttonDeleteBook.UseVisualStyleBackColor = true;
            buttonDeleteBook.Click += buttonDeleteBook_Click;
            // 
            // textBoxSearch
            // 
            textBoxSearch.Location = new Point(907, 56);
            textBoxSearch.Name = "textBoxSearch";
            textBoxSearch.Size = new Size(221, 23);
            textBoxSearch.TabIndex = 4;
            // 
            // buttonSearch
            // 
            buttonSearch.Location = new Point(907, 94);
            buttonSearch.Name = "buttonSearch";
            buttonSearch.Size = new Size(106, 42);
            buttonSearch.TabIndex = 5;
            buttonSearch.Text = "Пошук";
            buttonSearch.UseVisualStyleBackColor = true;
            buttonSearch.Click += buttonSearch_Click;
            // 
            // listViewBooks
            // 
            listViewBooks.FullRowSelect = true;
            listViewBooks.GridLines = true;
            listViewBooks.Location = new Point(12, 171);
            listViewBooks.Name = "listViewBooks";
            listViewBooks.Size = new Size(1154, 437);
            listViewBooks.TabIndex = 6;
            listViewBooks.UseCompatibleStateImageBehavior = false;
            listViewBooks.View = System.Windows.Forms.View.Details;
            listViewBooks.SelectedIndexChanged += listViewBooks_SelectedIndexChanged;
            // 
            // buttonCreateCollection
            // 
            buttonCreateCollection.Location = new Point(269, 69);
            buttonCreateCollection.Name = "buttonCreateCollection";
            buttonCreateCollection.Size = new Size(162, 42);
            buttonCreateCollection.TabIndex = 8;
            buttonCreateCollection.Text = "Створити колекцію";
            buttonCreateCollection.UseVisualStyleBackColor = true;
            buttonCreateCollection.Click += buttonCreateCollection_Click_1;
            // 
            // comboBoxSort
            // 
            comboBoxSort.FormattingEnabled = true;
            comboBoxSort.Location = new Point(135, 658);
            comboBoxSort.Name = "comboBoxSort";
            comboBoxSort.Size = new Size(181, 23);
            comboBoxSort.TabIndex = 9;
            comboBoxSort.SelectedIndexChanged += comboBoxSort_SelectedIndexChanged;
            // 
            // labelSort
            // 
            labelSort.AutoSize = true;
            labelSort.Location = new Point(186, 639);
            labelSort.Name = "labelSort";
            labelSort.Size = new Size(72, 15);
            labelSort.TabIndex = 10;
            labelSort.Text = "Сортування";
            // 
            // buttonResetSearch
            // 
            buttonResetSearch.Location = new Point(1029, 94);
            buttonResetSearch.Name = "buttonResetSearch";
            buttonResetSearch.Size = new Size(99, 42);
            buttonResetSearch.TabIndex = 11;
            buttonResetSearch.Text = "Очистити";
            buttonResetSearch.UseVisualStyleBackColor = true;
            buttonResetSearch.Click += buttonResetSearch_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(935, 28);
            label1.Name = "label1";
            label1.Size = new Size(159, 15);
            label1.TabIndex = 12;
            label1.Text = "Пошук (назва, автор, жанр)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(69, 62);
            label2.Name = "label2";
            label2.Size = new Size(103, 15);
            label2.TabIndex = 13;
            label2.Text = "Обрати колекцію";
            // 
            // comboBoxCollections
            // 
            comboBoxCollections.FormattingEnabled = true;
            comboBoxCollections.Location = new Point(42, 80);
            comboBoxCollections.Name = "comboBoxCollections";
            comboBoxCollections.Size = new Size(156, 23);
            comboBoxCollections.TabIndex = 14;
            comboBoxCollections.SelectedIndexChanged += comboBoxCollections_SelectedIndexChanged;
            // 
            // buttonDeleteCollection
            // 
            buttonDeleteCollection.Location = new Point(672, 69);
            buttonDeleteCollection.Name = "buttonDeleteCollection";
            buttonDeleteCollection.Size = new Size(162, 42);
            buttonDeleteCollection.TabIndex = 15;
            buttonDeleteCollection.Text = "Видалити колекцію";
            buttonDeleteCollection.UseVisualStyleBackColor = true;
            buttonDeleteCollection.Click += buttonDeleteCollection_Click_1;
            // 
            // buttonEditCollection
            // 
            buttonEditCollection.Location = new Point(473, 69);
            buttonEditCollection.Name = "buttonEditCollection";
            buttonEditCollection.Size = new Size(162, 42);
            buttonEditCollection.TabIndex = 16;
            buttonEditCollection.Text = "Редагувати колекцію";
            buttonEditCollection.UseVisualStyleBackColor = true;
            buttonEditCollection.Click += buttonEditCollection_Click;
            // 
            // FormMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1178, 713);
            Controls.Add(buttonEditCollection);
            Controls.Add(buttonDeleteCollection);
            Controls.Add(comboBoxCollections);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonResetSearch);
            Controls.Add(labelSort);
            Controls.Add(comboBoxSort);
            Controls.Add(buttonCreateCollection);
            Controls.Add(listViewBooks);
            Controls.Add(buttonSearch);
            Controls.Add(textBoxSearch);
            Controls.Add(buttonDeleteBook);
            Controls.Add(buttonEditBook);
            Controls.Add(buttonAddBook);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximumSize = new Size(1194, 752);
            MinimumSize = new Size(1194, 752);
            Name = "FormMain";
            Text = "Бібліотека";
            Load += FormMain_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button buttonAddBook;
        private Button buttonEditBook;
        private Button buttonDeleteBook;
        private TextBox textBoxSearch;
        private Button buttonSearch;
        private ListView listViewBooks;
        private Button buttonCreateCollection;
        private ComboBox comboBoxSort;
        private Label labelSort;
        private Button buttonResetSearch;
        private Label label1;
        private Label label2;
        private ComboBox comboBoxCollections;
        private Button buttonDeleteCollection;
        private Button buttonEditCollection;
    

        private void InitializeListViewColumns()
        {
            listViewBooks.Columns.Clear();
            listViewBooks.Columns.Add("Назва", 300);
            listViewBooks.Columns.Add("Автор", 250);
            listViewBooks.Columns.Add("Рік", 40);
            listViewBooks.Columns.Add("Жанр", 140);
            listViewBooks.Columns.Add("Колекція", 170);
            listViewBooks.Columns.Add("Джерело", 130);
            listViewBooks.Columns.Add("Статус", 100);
        }

        private void InitializeControllers()
        {
            bookManager = new BookManager();
            libraryStorage = new LibraryStorageController(bookManager);

            libraryStorage.LoadFromFile();
            bookManager.ReconnectBooksBetweenCollections();

            bookController = new BookController(bookManager, listViewBooks, libraryStorage);
            collectionController = new CollectionController(bookManager, comboBoxCollections, listViewBooks, bookController, libraryStorage);
            collectionController.LoadCollectionsToComboBox();
        }

        private void InitializeUI()
        {
            comboBoxSort.Items.AddRange(new string[]
            {
            "Назва (А-Я)",
            "Назва (Я-А)",
            "Автор (А-Я)",
            "Автор (Я-А)",
            "Рік (спочатку новіші)",
            "Рік (спочатку старіші)"
            });
            comboBoxSort.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSort.SelectedIndex = 0;
            comboBoxSort.SelectedIndexChanged += comboBoxSort_SelectedIndexChanged;
            Controls.Add(comboBoxSort);

            comboBoxCollections.SelectedIndexChanged += comboBoxCollections_SelectedIndexChanged;

        }
        private void LoadInitialBooks()
        {
            comboBoxCollections.SelectedItem = bookManager.Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");
            if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
            {
                bookController.DisplayBooks(selectedCollection, (string)comboBoxSort.SelectedItem);
            }
        }
    }
}