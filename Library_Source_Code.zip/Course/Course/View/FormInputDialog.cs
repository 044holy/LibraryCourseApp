﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course.View
{
    public partial class FormCollectionInput : Form
    {
        public string CollectionName => textBoxInput.Text.Trim();

        public FormCollectionInput()
        {
            InitializeComponent();
        }

        public FormCollectionInput(string initialName, bool isEditMode) : this()
        {
            textBoxInput.Text = initialName;
            Text = isEditMode ? "Редагування колекції" : "Створення нової колекції";
        }

        private void FormCollectionInput_Load(object sender, EventArgs e)
        {

        }

        private void textBoxInput_TextChanged(object sender, EventArgs e)
        { 
        
        }

        private void buttonOK_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxInput.Text))
            {
                MessageBox.Show("Назва колекції не може бути порожньою.");
                return;
            }

            DialogResult = DialogResult.OK;
            Close();
        }


        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
