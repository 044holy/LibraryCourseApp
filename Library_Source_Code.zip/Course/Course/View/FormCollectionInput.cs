﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course.View
{
    /// <summary>
    /// Форма для введення або редагування назви колекції книг.
    /// </summary>
    public partial class FormCollectionInput : Form
    {
        /// <summary>
        /// Повертає назву колекції, введену користувачем.
        /// </summary>
        public string CollectionName => textBoxInput.Text.Trim();

        /// <summary>
        /// Ініціалізує новий екземпляр форми.
        /// </summary>
        public FormCollectionInput()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Ініціалізує форму з початковою назвою вікна і режимом (створення або редагування).
        /// </summary>

        public FormCollectionInput(string initialName, bool isEditMode) : this()
        {
            textBoxInput.Text = initialName;
            Text = isEditMode ? "Редагування колекції" : "Створення нової колекції";
        }

        private void FormCollectionInput_Load(object sender, EventArgs e)
        { }

        private void textBoxInput_TextChanged(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// Обробник кнопки ОК, підтверджує введені дані та закриває форму.
        /// </summary>
        private void buttonOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            Close();
        }

        /// <summary>
        /// Обробник кнопки Скасувати, скасовує введення та закриває форму.
        /// </summary>
        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
