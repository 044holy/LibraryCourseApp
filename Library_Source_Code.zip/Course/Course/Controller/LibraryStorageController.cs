﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Course.Model;
using Newtonsoft.Json;
using static Course.Model.BookManager;
using static System.Reflection.Metadata.BlobBuilder;

namespace Course.Controller
{
    /// <summary>
    /// Контролер для збереження та завантаження бібліотеки книг у файл.
    /// </summary>
    public class LibraryStorageController
    {
        /// <summary>
        /// Колекція книг.
        /// </summary>
        public HashSet<Book> Books { get; } = new HashSet<Book>();

        /// <summary>
        /// Список колекцій книг.
        /// </summary>
        public List<BookCollection> Collections { get; } = new List<BookCollection>();

        private const string DataFile = "books_data.json";
        private BookManager bookManager;

        /// <summary>
        /// Екземпляр контролера.
        /// </summary>

        public LibraryStorageController(BookManager bookManager)
        {
            this.bookManager = bookManager ?? throw new ArgumentException(nameof(bookManager));
        }

        /// <summary>
        /// Зберігає дані бібліотеки у файл у форматі JSON.
        /// </summary>
        public void SaveToFile()
        {
            try
            {
                var data = bookManager.ExportLibraryData();
                var json = JsonConvert.SerializeObject(data, Formatting.Indented);
                File.WriteAllText(DataFile, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при збереженні: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Завантажує дані бібліотеки з файлу JSON, якщо файл існує.
        /// Якщо не існує колекції "Вся бібліотека", створює її.
        /// </summary>
        public void LoadFromFile()
        {
            if (File.Exists(DataFile))
            {
                try
                {
                    var json = File.ReadAllText(DataFile);
                    var data = JsonConvert.DeserializeObject<BookManager.LibraryData>(json);
                    if (data != null)
                    {
                        bookManager.ImportLibraryData(data);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка при завантаженні: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            if (!bookManager.Collections.Any(c => c.Name == "Вся бібліотека"))
            {
                var fullLibrary = new BookCollection("Вся бібліотека");

                foreach (var book in bookManager.GetAllBooks())
                {
                    fullLibrary.AddBook(book);
                }

                bookManager.Collections.Insert(0, fullLibrary);
            }
        }
    }
}
