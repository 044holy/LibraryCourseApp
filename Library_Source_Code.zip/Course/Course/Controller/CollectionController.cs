﻿using Course.Model;
using Course.View;
using System;
using System.Linq;
using System.Windows.Forms;

namespace Course.Controller
{
    /// <summary>
    /// Контролер для керування колекціями книг, їх відображенням і редагуванням.
    /// </summary>
    public class CollectionController
    {
        private readonly BookManager bookManager;
        private readonly ComboBox comboBoxCollections;
        private readonly ListView listViewBooks;
        private readonly BookController bookController;
        private LibraryStorageController libraryStorage;

        private const int MaxCollectionNameLength = 20;

        /// <summary>
        /// Ініціалізує екземпляр класу.
        /// </summary>
        public CollectionController(BookManager manager, ComboBox comboBox, ListView listView, BookController controller, LibraryStorageController storage)
        {
            bookManager = manager;
            comboBoxCollections = comboBox;
            listViewBooks = listView;
            bookController = controller;
            libraryStorage = storage;
        }

        /// <summary>
        /// Завантажує колекції у ComboBox для вибору користувачем.
        /// </summary>
        public void LoadCollectionsToComboBox()
        {
            comboBoxCollections.Items.Clear();

            var allLibrary = bookManager.Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");
            if (allLibrary != null)
                comboBoxCollections.Items.Add(allLibrary);

            comboBoxCollections.Items.AddRange(bookManager.Collections.Where(c => c.Name != "Вся бібліотека").ToArray());

            comboBoxCollections.SelectedItem = allLibrary ?? comboBoxCollections.Items.Cast<BookCollection>().FirstOrDefault();
        }

        /// <summary>
        /// Валідатор для назви колекції.
        /// </summary>
        private bool ValidateCollectionName(string name, bool isEditMode, string? oldName, out string errorMessage)
        {
            errorMessage = String.Empty;

            if (string.IsNullOrWhiteSpace(name))
            {
                errorMessage = "Назва колекції не може бути порожньою.";
                return false;
            }

            if (name.Length > MaxCollectionNameLength)
            {
                errorMessage = $"Назва колекції не може бути довшою за {MaxCollectionNameLength} символів.";
                return false;
            }

            bool nameExists = bookManager.Collections.Any(c => c.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
            if ((!isEditMode && nameExists) || (isEditMode && !string.Equals(oldName, name, StringComparison.OrdinalIgnoreCase) && nameExists))
            {
                errorMessage = "Колекція з такою назвою вже існує.";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Створює нову колекцію, після введення її назви користувачем.
        /// </summary>
        public void CreateCollection()
        {
            var form = new FormCollectionInput();

            if (form.ShowDialog() == DialogResult.OK)
            {
                string newCollectionName = form.CollectionName;

                if (!ValidateCollectionName(newCollectionName, false, null, out string error))
                {
                    MessageBox.Show(error, "Помилка створення колекції", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!bookManager.AddCollection(newCollectionName))
                {
                    MessageBox.Show("Колекція з такою назвою вже існує.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                LoadCollectionsToComboBox();

                var newCollection = bookManager.Collections.FirstOrDefault(c => c.Name == newCollectionName);
                if (newCollection != null)
                    comboBoxCollections.SelectedItem = newCollection;
            }
        }

        /// <summary>
        /// Видаляє вибрану колекцію (крім «Вся бібліотека»), і переносить книги до "Всієї бібліотеки".
        /// </summary>
        public void DeleteCollection()
        {
            if (comboBoxCollections.SelectedItem is not BookCollection selectedCollection)
            {
                MessageBox.Show("Виберіть колекцію для видалення.");
                return;
            }

            if (selectedCollection.Name == "Вся бібліотека")
            {
                MessageBox.Show("Колекція 'Вся бібліотека' зарезервована програмою, її не можна видалити.", "Неможливо видалити колекцію 'Вся бібліотека'", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var result = MessageBox.Show($"Ви впевнені, що хочете видалити колекцію '{selectedCollection.Name}'?\nКниги залишаться у 'Вся бібліотека'.", "Підтвердження видалення", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                var fullLibrary = bookManager.Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");

                if (fullLibrary != null)
                {
                    foreach (var book in selectedCollection.Books)
                    {
                        book.CollectionName = "Вся бібліотека";

                        if (!fullLibrary.Books.Contains(book))
                        {
                            fullLibrary.Books.Add(book);
                        }
                    }
                }

                bookManager.Collections.Remove(selectedCollection);
                comboBoxCollections.Items.Remove(selectedCollection);

                comboBoxCollections.SelectedItem = fullLibrary;
                if (fullLibrary != null)
                    bookController.DisplayBooks(fullLibrary);
            }
        }

        /// <summary>
        /// Редагує назву вибраної колекції (крім «Вся бібліотека»).
        /// </summary>
        public void EditCollection()
        {
            if (comboBoxCollections.SelectedItem is not BookCollection selectedCollection)
            {
                MessageBox.Show("Будь ласка, оберіть колекцію для редагування.");
                return;
            }

            if (selectedCollection.Name == "Вся бібліотека")
            {
                MessageBox.Show("Не можна редагувати головну колекцію 'Вся бібліотека'.", "Редагування головної колекції заборонено", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string oldName = selectedCollection.Name;

            var form = new FormCollectionInput(oldName, true);

            if (form.ShowDialog() == DialogResult.OK)
            {
                string newName = form.CollectionName;

                if (!ValidateCollectionName(newName, true, oldName, out string error))
                {
                    MessageBox.Show(error, "Помилка редагування колекції", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!string.Equals(oldName, newName, StringComparison.OrdinalIgnoreCase))
                {
                    selectedCollection.Name = newName;

                    foreach (var book in selectedCollection.Books)
                    {
                        book.CollectionName = newName;
                    }

                    LoadCollectionsToComboBox();

                    var updated = bookManager.Collections.FirstOrDefault(c => c.Name == newName);
                    if (updated != null)
                        comboBoxCollections.SelectedItem = updated;

                    libraryStorage.SaveToFile();
                }
            }
        }

        /// <summary>
        /// Обробляє зміну вибору колекції та оновлює відображення книг.
        /// </summary>
        public void CollectionChanging(BookCollection selectedCollection, string sortCriterion)
        {
            if (selectedCollection.Name == "Вся бібліотека")
            {
                bookManager.RebuildFullLibrary();
            }
            bookController.DisplayBooks(selectedCollection, sortCriterion);
        }

        
        
    }
}
