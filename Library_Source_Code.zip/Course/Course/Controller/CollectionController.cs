﻿using Course.Model;
using Course.View;
using System;
using System.Linq;
using System.Windows.Forms;

namespace Course.Controller
{
    public class CollectionController
    {
        private readonly BookManager bookManager;
        private readonly ComboBox comboBoxCollections;
        private readonly ListView listViewBooks;
        private readonly BookController bookController;
        private LibraryStorageController libraryStorage;

        public CollectionController(BookManager manager, ComboBox comboBox, ListView listView, BookController controller, LibraryStorageController storage)
        {
            bookManager = manager;
            comboBoxCollections = comboBox;
            listViewBooks = listView;
            bookController = controller;
            libraryStorage = storage;
        }

        public void LoadCollectionsToComboBox()
        {
            comboBoxCollections.Items.Clear();

            var allLibrary = bookManager.Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");
            if (allLibrary != null)
                comboBoxCollections.Items.Add(allLibrary);

            comboBoxCollections.Items.AddRange(bookManager.Collections.Where(c => c.Name != "Вся бібліотека").ToArray());

            comboBoxCollections.SelectedItem = allLibrary ?? comboBoxCollections.Items.Cast<BooksInCollections>().FirstOrDefault();
        }

        public void CreateCollection()
        {
            var form = new FormCollectionInput();

            if (form.ShowDialog() == DialogResult.OK)
            {
                string newCollectionName = form.CollectionName;

                if (!bookManager.AddCollection(newCollectionName))
                {
                    MessageBox.Show("Колекція з такою назвою вже існує.");
                    return;
                }

                LoadCollectionsToComboBox();

                var newCollection = bookManager.Collections.FirstOrDefault(c => c.Name == newCollectionName);
                if (newCollection != null)
                    comboBoxCollections.SelectedItem = newCollection;
            }
        }

        public void DeleteCollection()
        {
            if (comboBoxCollections.SelectedItem is not BooksInCollections selectedCollection)
            {
                MessageBox.Show("Виберіть колекцію для видалення.");
                return;
            }

            if (selectedCollection.Name == "Вся бібліотека")
            {
                MessageBox.Show("Колекція 'Вся бібліотека' зарезервована програмою, її не можна видалити.", "Неможливо видалити колекцію 'Вся бібліотека'", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var result = MessageBox.Show($"Ви впевнені, що хочете видалити колекцію '{selectedCollection.Name}'?\nКниги залишаться у 'Вся бібліотека'.", "Підтвердження видалення", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                var fullLibrary = bookManager.Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");

                if (fullLibrary != null)
                {
                    foreach (var book in selectedCollection.Books)
                    {
                        book.CollectionName = "Вся бібліотека";

                        if (!fullLibrary.Books.Contains(book))
                        {
                            fullLibrary.Books.Add(book);
                        }
                    }
                }

                bookManager.Collections.Remove(selectedCollection);
                comboBoxCollections.Items.Remove(selectedCollection);

                comboBoxCollections.SelectedItem = fullLibrary;
                if (fullLibrary != null)
                    bookController.DisplayBooks(fullLibrary);
            }
        }

        public void EditCollection()
        {
            if (comboBoxCollections.SelectedItem is not BooksInCollections selectedCollection)
            {
                MessageBox.Show("Будь ласка, оберіть колекцію для редагування.");
                return;
            }

            if (selectedCollection.Name == "Вся бібліотека")
            {
                MessageBox.Show("Не можна редагувати головну колекцію 'Вся бібліотека'.", "Редагування головної колекції заборонено", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string oldName = selectedCollection.Name;

            var form = new FormCollectionInput(oldName, true);

            if (form.ShowDialog() == DialogResult.OK)
            {
                string newName = form.CollectionName;

                if (!string.Equals(oldName, newName, StringComparison.OrdinalIgnoreCase))
                {
                    if (bookManager.Collections.Any(c => c.Name == newName))
                    {
                        MessageBox.Show("Колекція з такою назвою вже існує.");
                        return;
                    }

                    selectedCollection.Name = newName;

                    foreach (var book in selectedCollection.Books)
                    {
                        book.CollectionName = newName;
                    }

                    LoadCollectionsToComboBox();

                    var updated = bookManager.Collections.FirstOrDefault(c => c.Name == newName);
                    if (updated != null)
                        comboBoxCollections.SelectedItem = updated;

                    libraryStorage.SaveToFile();
                }
            }
        }

        public void CollectionChanging(BooksInCollections selectedCollection, string sortCriterion)
        {
            if (selectedCollection.Name == "Вся бібліотека")
            {
                bookManager.RebuildFullLibrary();
            }
            bookController.DisplayBooks(selectedCollection, sortCriterion);
        }

        
        
    }
}
