﻿using System;
using System.Drawing;

namespace Course.Model
{
    /// <summary>
    /// Клас для створення об'єкта Book з валідацією вхідних даних.
    public class BookCreator
    {
        /// <summary>
        /// Створює нову книгу з переданих параметрів, перевіряючи коректність введених даних.
        /// </summary>
        public static (Book? Book, string? ErrorMessage) CreateBook(
    string title, string author, string genre, string yearText,
    string filePath)
        {
            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author))
                return (null, "Рядок(рядки) пустий або заповнений пробілом");

            if (title.Length > 150 || author.Length > 100 || genre.Length > 100)
                return (null, "В рядок(рядки) введено забагато символів");

            int? year = null;

            if (!string.IsNullOrWhiteSpace(yearText))
            {
                if (int.TryParse(yearText, out int parsedYear) && yearText.Length == 4)
                    year = parsedYear;
                else
                    return (null, "Введено некоректний рік");
            }


            return (new Book
            {
                Title = title,
                Author = author,
                Year = year,
                Genre = genre,
                FilePath = filePath,
                CollectionName = "Вся бібліотека"
            }, null);
        }

    }
}
