﻿using static System.Reflection.Metadata.BlobBuilder;
using Newtonsoft.Json;
using System.IO;

namespace Course.Model
{
    /// <summary>
    /// Модель колекції книг, що містить посилання на книги через їх ідентифікатори самі об'єкти книг.
    /// </summary>
    public class BookCollection
    {
        /// <summary>
        /// Назва колекції.
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// Ідентифікатори книг, що належать до колекції.
        /// </summary>
        public List<Guid> BookIds { get; set; } = new List<Guid>();

        /// <summary>
        /// Колекція об'єктів книг, що належать до колекції.
        /// Не серіалізується у JSON.
        /// </summary>
        /// 
        [JsonIgnore]
        public List<Book> Books { get; set; } = new List<Book>();

        public BookCollection() { }

        /// <summary>
        /// Ініціалізує новий екземпляр колекції з заданою назвою.
        /// </summary>
        public BookCollection(string name) : this()
        {
            Name = name;
        }

        /// <summary>
        /// Повертає назву колекції.
        /// </summary>
        public override string ToString()
        {
            return Name;
        }

        /// <summary>
        /// Додає книгу до колекції, якщо її там ще немає.
        /// </summary>
        public void AddBook(Book book)
        {
            if (!BookIds.Contains(book.Id))
                BookIds.Add(book.Id);

            if (!Books.Contains(book))
                Books.Add(book);
        }

        /// <summary>
        /// Видаляє книгу з колекції.
        /// </summary>
        public void RemoveBook(Book book)
        {
            if (book == null) return;

            Books.RemoveAll(b => b.Id == book.Id);
            BookIds.Remove(book.Id);
        }

        /// <summary>
        /// Завантажує об'єкти книг у властивість Books за списком їх ідентифікаторів,
        /// використовуючи переданий словник усіх книг.
        /// </summary>
        public void LoadBooksFromID(Dictionary<Guid, Book> bookDict)
        {
            Books.Clear();
            foreach (var id in BookIds)
            {
                if (bookDict.TryGetValue(id, out var book))
                {
                    Books.Add(book);
                }
            }
        }
    }
}
