﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System.ComponentModel;

namespace Course.Model
{
    /// <summary>
    /// Перелік джерел походження книги.
    /// </summary>
    public enum BookSource
    {
        [Description("Невідомо")]
        Unknown,
        [Description("Придбана")]
        Purchased,
        [Description("Подарована")]
        Gifted,
        [Description("Завантажена")]
        Downloaded,
        [Description("Інше")]
        Other
    }

    /// <summary>
    /// Перелік статусів книги.
    /// </summary>
    public enum BookStatus
    {
        [Description("Не читав")]
        NotRead,
        [Description("Читаю")]
        Reading,
        [Description("Планую читати")]
        PlannedToRead,
        [Description("Прочитана")]
        FinishedReading,
        [Description("Бросив читати")]
        Abandoned,
        [Description("Відклав читати")]
        OnHold
    }

    /// <summary>
    /// Основні властивості об'єкта книги.
    /// </summary>
    public class Book
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Title { get; set; } = "";
        public string Author { get; set; } = "";
        public string Genre { get; set; } = "";
        public int? Year { get; set; }

        /// <summary>
        /// Шлях до файлу книги який обирається на формі додавання(редагування) книги.
        /// </summary>
        public string FilePath { get; set; } = "";
        public string CollectionName { get; set; } = "";
        public BookSource Source { get; set; }
        public BookStatus Status { get; set; }

    }
}
