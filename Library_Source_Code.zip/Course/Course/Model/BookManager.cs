﻿using System.Collections.Generic;
using static System.Reflection.Metadata.BlobBuilder;
using System.Linq;
using Newtonsoft.Json;
using System.IO;
using Course.Controller;
using System.Windows.Forms;
using System.Diagnostics;

namespace Course.Model
{
    /// <summary>
    /// Клас для керування колекціями книг.
    /// </summary>
    public class BookManager
    {

        public HashSet<Book> Books { get; } = new HashSet<Book>();
        public List<BookCollection> Collections { get; } = new List<BookCollection>();

        public BookManager()
        {
            
        }

        /// <summary>
        /// Допоміжний клас для серіалізації/десеріалізації даних бібліотеки.
        /// </summary>
        public class LibraryData
        {
            public List<Book> Books { get; set; } = new();
            public List<BookCollection> Collections { get; set; } = new();
        }

        /// <summary>
        /// Експортує поточні дані бібліотеки.
        /// </summary>
        public LibraryData ExportLibraryData()
        {
            return new LibraryData
            {
                Books = Books.ToList(),
                Collections = Collections
            };
        }

        /// <summary>
        /// Імпортує дані бібліотеки.
        /// </summary>
        public void ImportLibraryData(LibraryData data)
        {
            Books.Clear();
            foreach (var book in data.Books ?? new List<Book>())
            {
                Books.Add(book);
            }

            Collections.Clear();
            foreach (var collection in data.Collections ?? new List<BookCollection>())
            {
                Collections.Add(collection);
            }

            RebuildFullLibrary();

            var bookDict = Books.ToDictionary(b => b.Id);
            foreach (var collection in Collections)
            {
                collection.LoadBooksFromID(bookDict);
            }

            var fullLibrary = Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");
            if (fullLibrary != null && Collections[0] != fullLibrary)
            {
                Collections.Remove(fullLibrary);
                Collections.Insert(0, fullLibrary);
            }
            else if (fullLibrary == null)
            {
                fullLibrary = new BookCollection("Вся бібліотека");
                Collections.Insert(0, fullLibrary);
                RebuildFullLibrary();
            }
        }

        /// <summary>
        /// Додає книгу до менеджера та відповідної колекції.
        /// </summary>
        public void AddBook(Book book)
        {
            Books.Add(book);

            var targetCollection = Collections.FirstOrDefault(c => c.Name == book.CollectionName);
            if (targetCollection == null)
            {
                targetCollection = new BookCollection(book.CollectionName);
                Collections.Add(targetCollection);
            }
            targetCollection.AddBook(book);

            RebuildFullLibrary();
        }

        /// <summary>
        /// Видаляє книгу з менеджера та колекцій.
        /// </summary>
        public void RemoveBook(Book book)
        {
            Books.Remove(book);

            foreach (var collection in Collections)
            {
                collection.RemoveBook(book);
            }

            RebuildFullLibrary();
        }

        /// <summary>
        /// Повертає список усіх книг.
        /// </summary>
        public List<Book> GetAllBooks()
        {
            return Books.ToList();
        }

        /// <summary>
        /// Додає нову колекцію
        /// </summary>
        public bool AddCollection(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return false;
            if (Collections.Any(c => c.Name == name)) return false;

            Collections.Add(new BookCollection(name));
            return true;
        }

        /// <summary>
        /// Оновлює посилання на книги між колекціями.
        /// </summary>
        public void ReconnectBooksBetweenCollections()
        {
            var allLibrary = Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");
            if (allLibrary == null) return;

            foreach (var collection in Collections)
            {
                if (collection.Name == "Вся бібліотека") continue;

                for (int i = 0; i < collection.Books.Count; i++)
                {
                    var bookInCol = collection.Books[i];
                    var realBook = allLibrary.Books.FirstOrDefault(b => b.Id == bookInCol.Id);
                    if (realBook != null)
                        collection.Books[i] = realBook;
                }
            }
        }

        /// <summary>
        /// Оновлює існуючу книгу.
        /// </summary>
        public void UpdateBook(Book updatedBook)
        {
            var existingBook = Books.FirstOrDefault(b => b.Id == updatedBook.Id);
            if (existingBook != null)
            {
                foreach (var collection in Collections)
                {
                    if (collection.Name != "Вся бібліотека")
                    {
                        collection.RemoveBook(existingBook);
                    }
                }

                existingBook.Title = updatedBook.Title;
                existingBook.Author = updatedBook.Author;
                existingBook.Year = updatedBook.Year;
                existingBook.Genre = updatedBook.Genre;
                existingBook.FilePath = updatedBook.FilePath;
                existingBook.Source = updatedBook.Source;
                existingBook.Status = updatedBook.Status;
                existingBook.CollectionName = updatedBook.CollectionName;

                var newCollection = Collections.FirstOrDefault(c => c.Name == updatedBook.CollectionName);
                if (newCollection == null)
                {
                    newCollection = new BookCollection(updatedBook.CollectionName);
                    Collections.Add(newCollection);
                }
                newCollection.AddBook(existingBook);
            }

            RebuildFullLibrary();
        }

        /// <summary>
        /// Перебудовує колекцію "Вся бібліотека".
        /// </summary>
        public void RebuildFullLibrary()
        {
            var fullLibrary = Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");
            if (fullLibrary == null)
            {
                fullLibrary = new BookCollection("Вся бібліотека");
                Collections.Insert(0, fullLibrary);
            }
            fullLibrary.Books.Clear();
            fullLibrary.BookIds.Clear();

            foreach (var book in Books)
            {
                fullLibrary.AddBook(book);
            }
        }

    }
}
