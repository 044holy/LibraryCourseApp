﻿using static System.Reflection.Metadata.BlobBuilder;
using Newtonsoft.Json;
using System.IO;

namespace Course.Model
{
    public class BooksInCollections
    {
        public string Name { get; set; }
        public List<Guid> BookIds { get; set; } = new List<Guid>();

        [JsonIgnore]
        public List<Book> Books { get; set; } = new List<Book>();

        public BooksInCollections() { }

        public BooksInCollections(string name) : this()
        {
            Name = name;
        }

        public override string ToString()
        {
            return Name;
        }

        public void AddBook(Book book)
        {
            if (!BookIds.Contains(book.Id))
                BookIds.Add(book.Id);

            if (!Books.Contains(book))
                Books.Add(book);
        }

        public void RemoveBook(Book book)
        {
            if (book == null) return;

            Books.RemoveAll(b => b.Id == book.Id);
            BookIds.Remove(book.Id);
        }


        public void LoadBooksFromID(Dictionary<Guid, Book> bookDict)
        {
            Books.Clear();
            foreach (var id in BookIds)
            {
                if (bookDict.TryGetValue(id, out var book))
                {
                    Books.Add(book);
                }
            }
        }
    }
}
