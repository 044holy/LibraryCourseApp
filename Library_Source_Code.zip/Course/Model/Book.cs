﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System.ComponentModel;

namespace Course.Model
{

    public enum BookSource
    {
        [Description("Невідомо")]
        Unknown,
        [Description("Придбана")]
        Purchased,
        [Description("Подарована")]
        Gifted,
        [Description("Завантажена")]
        Downloaded,
        [Description("Інше")]
        Other
    }

    public enum BookStatus
    {
        [Description("Не читав")]
        NotRead,
        [Description("Читаю")]
        Reading,
        [Description("Планую читати")]
        PlannedToRead,
        [Description("Прочитана")]
        FinishedReading,
        [Description("Бросив читати")]
        Abandoned,
        [Description("Відклав читати")]
        OnHold
    }

    public class Book
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Title { get; set; } = "";
        public string Author { get; set; } = "";
        public string Genre { get; set; } = "";
        public int? Year { get; set; }
        public string FilePath { get; set; } = "";
        public string CollectionName { get; set; } = "";
        public BookSource Source { get; set; }
        public BookStatus Status { get; set; }

    }
}
