﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using Course.Model;

namespace Course.View
{
    public partial class FormAddEditBook : Form
    {
        public Book? NewBook { get; private set; }
        private string selectedFilePath = "";
        private bool isEditMode = false;
        private Book? originalBook;

        private bool suppressCollectionChange = false;

        public FormAddEditBook()
        {
            InitializeComponent();

            comboBoxSource.DataSource = Enum.GetValues(typeof(BookSource))
                                           .Cast<BookSource>()
                                           .Select(e => new { Value = e, Name = e.GetDescription() })
                                           .ToList();

            comboBoxStatus.DataSource = Enum.GetValues(typeof(BookStatus))
                                          .Cast<BookStatus>()
                                          .Select(e => new { Value = e, Name = e.GetDescription() })
                                          .ToList();

            if (comboBoxSource.Items.Count > 0)
            {
                comboBoxSource.SelectedIndex = 0;
            }

            if (comboBoxStatus.Items.Count > 0)
                comboBoxStatus.SelectedIndex = 0;
        }


        public FormAddEditBook(Book bookToEdit) : this()
        {
            isEditMode = true;
            originalBook = bookToEdit;

            textBoxTitle.Text = bookToEdit.Title;
            textBoxAuthor.Text = bookToEdit.Author;
            textBoxGenre.Text = bookToEdit.Genre;
            textBoxYear.Text = bookToEdit.Year?.ToString() ?? "";
            selectedFilePath = bookToEdit.FilePath;

            comboBoxSource.SelectedItem = comboBoxSource.Items
                .Cast<dynamic>()
                .FirstOrDefault(item => (BookSource)item.Value == bookToEdit.Source);

            comboBoxStatus.SelectedItem = comboBoxStatus.Items
                .Cast<dynamic>()
                .FirstOrDefault(item => (BookStatus)item.Value == bookToEdit.Status);
        }

        private void buttonSelectFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "Файли книг|*.pdf;*.epub;*.txt;*.fb2;*.djvu;|Всі файли|*.*"
            };

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                selectedFilePath = dialog.FileName;
                textBoxTitle.Text = Path.GetFileNameWithoutExtension(selectedFilePath);
            }
        }


        private void buttonSave_Click(object sender, EventArgs e)
        {
            BookSource source = (BookSource)comboBoxSource.SelectedValue;
            BookStatus status = (BookStatus)comboBoxStatus.SelectedValue;

            var (book, error) = BookCreator.CreateBook(
                textBoxTitle.Text,
                textBoxAuthor.Text,
                textBoxGenre.Text,
                textBoxYear.Text,
                selectedFilePath
            );

            if (error != null)
            {
                MessageBox.Show(error);
                return;
            }


            if (isEditMode && originalBook is Book editableBook)
            {
                editableBook.Title = book.Title;
                editableBook.Author = book.Author;
                editableBook.Genre = book.Genre;
                editableBook.Year = book.Year;
                editableBook.FilePath = book.FilePath;

                editableBook.CollectionName = GetSelectedCollectionName();

                editableBook.Source = source;
                editableBook.Status = status;

                NewBook = editableBook;
            }
            else
            {
                book.Source = source;
                book.Status = status;
                book.CollectionName = GetSelectedCollectionName();
                NewBook = book;
            }

            DialogResult = DialogResult.OK;
            Close();
        }



        private void buttonCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void comboBoxCollections_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
 

        public void SetCollections(List<BooksInCollections> collections)
        {
            suppressCollectionChange = true;

            comboBoxCollections.Items.Clear();

            if (collections.Count > 0)
            {
                comboBoxCollections.Items.AddRange(collections.ToArray());

                if (isEditMode && originalBook != null)
                {
                    var existing = collections.FirstOrDefault(c => c.Name == originalBook.CollectionName);
                    if (existing != null)
                        comboBoxCollections.SelectedItem = existing;
                }

                if (comboBoxCollections.SelectedIndex == -1 && comboBoxCollections.Items.Count > 0)
                    comboBoxCollections.SelectedIndex = 0;
            }

            suppressCollectionChange = false;
        }


        private string GetSelectedCollectionName()
        {
            if (comboBoxCollections.SelectedItem is BooksInCollections collection)
                return collection.Name;
            return "";
        }

    }

}