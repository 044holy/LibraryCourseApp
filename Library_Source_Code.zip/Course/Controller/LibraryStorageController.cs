﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Course.Model;
using Newtonsoft.Json;
using static Course.Model.BookManager;
using static System.Reflection.Metadata.BlobBuilder;

namespace Course.Controller
{
    public class LibraryStorageController
    {
        public HashSet<Book> Books { get; } = new HashSet<Book>();
        public List<BooksInCollections> Collections { get; } = new List<BooksInCollections>();

        private const string DataFile = "books_data.json";
        private BookManager bookManager;

        public LibraryStorageController(BookManager bookManager)
        {
            this.bookManager = bookManager ?? throw new ArgumentException(nameof(bookManager));
        }

        public void SaveToFile()
        {
            try
            {
                var data = bookManager.ExportLibraryData();
                var json = JsonConvert.SerializeObject(data, Formatting.Indented);
                File.WriteAllText(DataFile, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка при збереженні: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void LoadFromFile()
        {
            if (File.Exists(DataFile))
            {
                try
                {
                    var json = File.ReadAllText(DataFile);
                    var data = JsonConvert.DeserializeObject<BookManager.LibraryData>(json);
                    if (data != null)
                    {
                        bookManager.ImportLibraryData(data);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка при завантаженні: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            if (!bookManager.Collections.Any(c => c.Name == "Вся бібліотека"))
            {
                var fullLibrary = new BooksInCollections("Вся бібліотека");

                foreach (var book in bookManager.GetAllBooks())
                {
                    fullLibrary.AddBook(book);
                }

                bookManager.Collections.Insert(0, fullLibrary);
            }
        }
    }
}
