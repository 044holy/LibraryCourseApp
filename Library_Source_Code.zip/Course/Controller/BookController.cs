﻿using Course.Model;
using Course.View;
using System.Drawing;
using System.Windows.Forms;

namespace Course.Controller
{
    public class BookController
    {
        private readonly BookManager bookManager;
        private readonly ListView listViewBooks;
        private LibraryStorageController libraryStorage;

        public BookController(BookManager bookManager, ListView listViewBooks, LibraryStorageController libraryStorage)
        {

            this.bookManager = bookManager ?? throw new ArgumentNullException(nameof(bookManager));
            this.listViewBooks = listViewBooks ?? throw new ArgumentNullException(nameof(listViewBooks));
            this.libraryStorage = libraryStorage ?? throw new ArgumentNullException(nameof(libraryStorage));
        }

        public void AddBook(Book book)
        {
            foreach (ListViewItem item in listViewBooks.Items)
            {
                if (item.Tag == book)
                    return;
            }

            bookManager.AddBook(book);
            AddBookToListView(book);
        }

        public void RemoveSelectedBooks()
        {
            var selectedItems = listViewBooks.SelectedItems;
            if (selectedItems.Count == 0)
            {
                MessageBox.Show("Виберіть книгу(-и) для видалення");
                return;
            }

            var booksToRemove = new List<Book>();

            foreach (ListViewItem item in selectedItems)
            {
                if (item.Tag is Book book)
                {
                    booksToRemove.Add(book);
                }
            }

            foreach (var book in booksToRemove)
            {
                bookManager.RemoveBook(book);
            }
            libraryStorage.SaveToFile();

            foreach (ListViewItem item in selectedItems)
            {
                listViewBooks.Items.Remove(item);
            }
        }

        public void AddBookToListView(Book book)
        {

            var item = new ListViewItem(book.Title ?? "");
            item.SubItems.Add(book.Author ?? "");
            item.SubItems.Add(book.Year?.ToString() ?? "");
            item.SubItems.Add(book.Genre ?? "");
            item.SubItems.Add(book.CollectionName ?? "");
            item.SubItems.Add(book.Source.GetDescription());
            item.SubItems.Add(book.Status.GetDescription());

            item.Tag = book;

            listViewBooks.Items.Add(item);
        }

        public void UpdateBookInListView(ListViewItem item, Book book)
        {

            item.Text = book.Title ?? "";

            while (item.SubItems.Count < 7)
            {
                item.SubItems.Add("");
            }

            item.SubItems[1].Text = book.Author ?? "";
            item.SubItems[2].Text = book.Year?.ToString() ?? "";
            item.SubItems[3].Text = book.Genre ?? "";
            item.SubItems[4].Text = book.CollectionName ?? "";
            item.SubItems[5].Text = book.Source.GetDescription();
            item.SubItems[6].Text = book.Status.GetDescription();

            item.Tag = book;
        }
        

        public void SortBooks(string criterion)
        {
            var books = bookManager.GetAllBooks();
            IEnumerable<Book> sorted;

            bool anyWithYear = books.Any(b => b.Year.HasValue);

            sorted = criterion switch
            {
                "Назва (А-Я)" => books.OrderBy(b => b.Title),
                "Автор (А-Я)" => books.OrderBy(b => b.Author),
                "Рік (спочатку новіші)" => anyWithYear
                    ? books.OrderByDescending(b => b.Year.HasValue).ThenByDescending(b => b.Year)
                    : books,
                "Рік (спочатку старіші)" => anyWithYear
                    ? books.OrderByDescending(b => b.Year.HasValue).ThenBy(b => b.Year)
                    : books,
                _ => books
            };

            listViewBooks.Items.Clear();

            foreach (var book in sorted)
            {
                AddBookToListView(book);
            }

        }

        public void SearchBooks(string query, BooksInCollections? collection = null)
        {
            listViewBooks.Items.Clear();

            IEnumerable<Book> books;

            if (collection == null)
            {
                books = bookManager.GetAllBooks();
            }
            else
            {
                books = collection.Books;
            }

            var filtered = books.Where(b =>
                (!string.IsNullOrEmpty(b.Title) && b.Title.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (!string.IsNullOrEmpty(b.Author) && b.Author.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (!string.IsNullOrEmpty(b.Genre) && b.Genre.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (b.Source.GetDescription().IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (b.Status.GetDescription().IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
            ).ToList();


            foreach (var book in filtered)
            {
                AddBookToListView(book);
            }
        }

        public void DisplayBooks(BooksInCollections? collection = null, string? sortCriterion = null)
        {
            listViewBooks.Items.Clear();

            IEnumerable<Book> books = collection?.Books ?? bookManager.GetAllBooks();

            bool anyWithYear = books.Any(b => b.Year.HasValue);

            books = sortCriterion switch
            {
                "Назва (А-Я)" => books.OrderBy(b => b.Title),
                "Назва (Я-А)" => books.OrderByDescending(b => b.Title),
                "Автор (А-Я)" => books.OrderBy(b => b.Author),
                "Автор (Я-А)" => books.OrderByDescending(b => b.Author),
                "Рік (спочатку новіші)" => anyWithYear
                    ? books.OrderByDescending(b => b.Year ?? int.MinValue)
                    : books,
                "Рік (спочатку старіші)" => anyWithYear
                    ? books.OrderBy(b => b.Year ?? int.MaxValue)
                    : books,
                _ => books
            };

            foreach (var book in books)
            {
                AddBookToListView(book);
            }
        }

        public void AddBook(ComboBox comboBoxCollections, ComboBox comboBoxSort)
        {
            var form = new View.FormAddEditBook();
            form.SetCollections(bookManager.Collections);

            if (form.ShowDialog() == DialogResult.OK && form.NewBook != null)
            {
                var newBook = form.NewBook;

                var allLibrary = bookManager.Collections.FirstOrDefault(c => c.Name == "Вся бібліотека");
                if (allLibrary != null && !allLibrary.Books.Contains(newBook))
                {
                    allLibrary.Books.Add(newBook);
                }

                var targetCollection = bookManager.Collections.FirstOrDefault(c => c.Name == newBook.CollectionName);
                if (targetCollection != null && !targetCollection.Books.Contains(newBook))
                {
                    targetCollection.Books.Add(newBook);
                }

                AddBook(newBook);

                if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
                {
                    DisplayBooks(selectedCollection, (string)comboBoxSort.SelectedItem);
                }
            }
        }

        public void EditBook(ComboBox comboBoxCollections, ComboBox comboBoxSort)
        {
            if (listViewBooks.SelectedItems.Count == 0)
            {
                MessageBox.Show("Будь ласка, оберіть хоча б одну книгу для редагування.", "Помилка редагування",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (listViewBooks.SelectedItems.Count > 1)
            {
                MessageBox.Show("Неможливо редагувати кілька книг одночасно. Будь ласка, оберіть лише одну книгу.",
                                "Помилка редагування", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedItem = listViewBooks.SelectedItems[0];
            var originalBook = (Book)selectedItem.Tag;

            var form = new View.FormAddEditBook(originalBook);
            form.SetCollections(bookManager.Collections);

            if (form.ShowDialog() == DialogResult.OK && form.NewBook != null)
            {
                var updatedBook = form.NewBook;

                bookManager.UpdateBook(updatedBook);
                libraryStorage.SaveToFile();
                UpdateBookInListView(selectedItem, updatedBook);

                if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
                {
                    DisplayBooks(selectedCollection, (string)comboBoxSort.SelectedItem);
                }
            }
        }

        public void DeleteBooks(ComboBox comboBoxCollections, ComboBox comboBoxSort)
        {
            int selectedCount = listViewBooks.SelectedItems.Count;

            if (selectedCount == 0)
            {
                MessageBox.Show("Будь ласка, виберіть хоча б одну книгу для видалення.",
                                "Немає вибраних книг для видалення", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string message = selectedCount == 1
                ? "Ви впевнені, що хочете видалити цю книгу?"
                : $"Ви впевнені, що хочете видалити {selectedCount} книг(и)?";

            DialogResult result = MessageBox.Show(message,
                                                  "Підтвердження видалення",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                RemoveSelectedBooks();

                if (comboBoxCollections.SelectedItem is BooksInCollections selectedCollection)
                {
                    DisplayBooks(selectedCollection, (string)comboBoxSort.SelectedItem);
                }
            }
        }

        public void Sort(BooksInCollections selectedCollection, string sortCriterion)
        {
            DisplayBooks(selectedCollection, sortCriterion);
        }

        public void Search(string query, BooksInCollections? collection = null)
        {
            if (string.IsNullOrWhiteSpace(query))
            {
                MessageBox.Show("Будь ласка, введіть щось для пошуку.", "Пустий пошуковий запит", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (collection != null)
                {
                    DisplayBooks(collection);
                }
                return;
            }

            SearchBooks(query, collection);

            if (listViewBooks.Items.Count == 0)
            {
                MessageBox.Show($"Книг за запитом \"{query}\" не знайдено.", "Пошук не дав результатів", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void ResetSearch(BooksInCollections selectedCollection, string sortCriterion)
        {
            DisplayBooks(selectedCollection, sortCriterion);
        }
    }
}